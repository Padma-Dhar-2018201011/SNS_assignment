# client.py

# key generation phase

import socket 
import random 
import pickle
import os
import math
#import lib
import sys
import hashlib


START_BASE_FOR_PRIMES=10000
PRIME_RANGE=10000
RABIN_TEST_FREQUENCY=5


class Header:
	def __init__(self, opcode, s_addr, d_addr):
		self.opcode = opcode
		self.s_addr = s_addr
		self.d_addr = d_addr

class Signature:
	def __init__(self, c, s):
		self.c = c
		self.s = s

class Message:
	def __init__(self, opcode, s_addr, d_addr, q=0, g=0, y1=0, y2=0, plainText="",c=0, s=0, ver_status=False):
		self.hdr = Header(opcode, s_addr, d_addr)
		self.q = q
		self.g = g
		self.y1 = y1
		self.y2 = y2
		#self.alpha = alpha
		#self.a = a
		self.plainText = plainText
		self.sign = Signature(c, s)
		self.ver_status = ver_status
		self.dummy = 0








def fme(base, expo, mod):
	"""
	Function that performs Fast Modular Exponentiation
	"""
	x = 1
	y = base
	while (expo > 0):
		if (expo % 2 == 1):
			x = (x * y) % mod
		y = (y * y) % mod
		expo = expo / 2
	return x % mod



def computeModularPow(a_random, multiplier, inputForPrime):
    finalResult = 1
    a_random = a_random % inputForPrime
    modd=0
    while(multiplier > 0):
        if(multiplier % 2):
            finalResult = (finalResult * a_random) % inputForPrime
            modd+=1
        

        multiplier >>= 1
        a_random = (a_random * a_random) % inputForPrime
        modd+=1
    
    return finalResult




def calcPrimitiveRoot(primeNumber):
    candidates=[0]*(primeNumber)
    primRoot=0
    notRoot = 0

    #Try for all numbers from 2 to p-1

    the_prime_number=2
    for r in range(2,primeNumber):
        for x in range(0,primeNumber-1):
            candidates[x] = computeModularPow(r, x, primeNumber)
            the_prime_number=candidates[x]
        

        # Check for duplicates in the candidate array
        for i in range(0,primeNumber):
            for j in range(0,primeNumber):
                if(candidates[i] == candidates[j] and not i == j):
                    notRoot = 1
                    break
                
            
            if(notRoot):
                break
        

        if(notRoot):
            notRoot = 0
            primRoot = -1
            the_prime_number=-1
        
        else:
            primRoot = r
            the_prime_number=r
            break
        
    

    return primRoot




def checkPrimeUsingRabinMillerUtil(inputForPrime, multiplier):
    # Choosing a random_val in the range [2, n-2]
    a_random = (random.randrange(0,10000,1) % (inputForPrime - 3)) + 2
    
    # Computing Modular Exponentiation & Checking the primality Conditions 
    b_0 = computeModularPow(a_random, multiplier, inputForPrime)

    if(b_0 == 1 or b_0 == inputForPrime - 1):
        return 1

    if(b_0==1):
    	return 1
    if(b_0==inputForPrime-1):
    	return 1

    while(multiplier < inputForPrime - 1):
        b_0 = (b_0 * b_0) % inputForPrime
        multiplier *= 2
        if(b_0 == inputForPrime - 1):
            return 1
        if(b_0 == 1):
            return 0

    

    #If multiplier reached inputForPrime-1 => composite
    return 0


def checkPrimeUsingRabinMiller(inputForPrime):
    # Compute k & m such that n-1 = 2^k * m 
    multiplier = inputForPrime - 1
    while multiplier % 2 == 0:
        multiplier/=2

    # Now repeat the test for RABIN_TEST_FREQUENCY time
    for i in range(0,RABIN_TEST_FREQUENCY):
        if(not checkPrimeUsingRabinMillerUtil(inputForPrime, multiplier)):
            return 0
    
    return 1









	# q is a prime no that we got using rabin miller
if(len(sys.argv)) <2:
	print "Please mention the server IP"
	exit(0)


primeNumber=START_BASE_FOR_PRIMES+random.randrange(0,10000,1)

while(not checkPrimeUsingRabinMiller(primeNumber)):
    primeNumber = START_BASE_FOR_PRIMES+random.randrange(0,10000,1)

#primeNumber=11

a=random.randrange(1,primeNumber-1)
q=primeNumber
g=calcPrimitiveRoot(primeNumber)
#q=11
# fast exponentiation
#y1=(g ** a) % q
y1=fme(g,a,q)
#y2=(y1 ** a) % q

y2=fme(y1,a,q)

Zq=[]
for i in range(1,q-1):
	Zq.append(i)

print"#####################################################################################"
print ""
print ""
print "primeNumber         " , primeNumber
print ""
print "a       " , a
print ""
print "g        " , g
print ""
print "y1      ", y1
print ""
print "y2       ",y2
print ""
print ""
print "####################################################################################"

	# hash function
	# SHA1

# hash_object = hashlib.sha1(concatted_pwd)
# hex_dig = hash_object.hexdigest()

sock = socket.socket()         
port = 12345    

buff=str(primeNumber)+":"+str(g)+":"+str(y1)+":"+str(y2)+":10"

sock.connect((sys.argv[1], port))
sock.send(buff)



##################SIGNITURE GENERATION PHASE

message=raw_input("ENter message")
#a=random.randint(1,q-1)
random_no=random.randint(1,q-1)

# signer calculates A,B,c,s

A=fme(g,random_no,q)
B=fme(y1,random_no,q)

c1=str(A)+str(B)+message
hash_object = hashlib.sha1(c1)
c = hash_object.hexdigest()

#i = int(c, 16) #int of the H(a,b,m)

s=a*int(c, 16)+(random_no)%q #ac+rmodq


print "####################################################################################"
print ""
print ""
print "SIgniture generation phase"
print ""
print "message" , message
print ""
print "random_no",random_no
print ""
print "A" , A
print ""
print "B" ,B
print ""
print "c1", c1
print ""
print "c",c
#print "i", i
print ""
print "s",s
print ""
print ""
print "####################################################################################"
# do the part 3

sigma=str(c)+":"+str(s) # for the message m
print ""
print "sigma", sigma
print ""
# this is sent to the verifier
buff=str(message)+":"+str(sigma)+":20"
sock.send(buff)


buffer1=sock.recv(1024)
a,b=buffer1.split(":")
print ""
print "opcode"
print a
print ""
print ""
print "Status received by client is"
if(b=='0' or b==0):
 	print "Failed"
else:
 	print "SUccess"


