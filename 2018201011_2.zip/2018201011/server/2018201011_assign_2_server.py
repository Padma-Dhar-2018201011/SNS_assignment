#server.py

import socket               
import hashlib
import pickle



class Header:
	def __init__(self, opcode, s_addr, d_addr):
		self.opcode = opcode
		self.s_addr = s_addr
		self.d_addr = d_addr

class Signature:
	def __init__(self, c, s):
		self.c = c
		self.s = s

class Message:
	def __init__(self, opcode, s_addr, d_addr, q=0, g=0, y1=0, y2=0, plainText="", c=0, s=0, ver_status=False):
		self.hdr = Header(opcode, s_addr, d_addr)
		self.q = q
		self.g = g
		self.y1 = y1
		self.y2 = y2
		#self.alpha = alpha
		#self.a = a
		self.plainText = plainText
		self.sign = Signature(c, s)
		self.ver_status = ver_status
		self.dummy = 0



def extEuclid(a, b):
    x,y, u,v = 0,1, 1,0
    while a != 0:
        q,r = b//a,b%a; m,n = x-u*q,y-v*q # use x//y for floor "floor division"
        b,a, x,y, u,v = a,r, u,v, m,n
    return b, x, y



def extendedGcd(inputA, inputB):

    # Using Extended Euclidean Algorithm
    x0, x1, y0, y1 = 1, 0, 0, 1
    while inputB != 0:
        q, inputA, inputB = inputA // inputB, inputB, inputA % inputB
        x0, x1 = x1, x0 - q * x1
        y0, y1 = y1, y0 - q * y1

    return x0


 
def modinv(a, m):
    g, x, y = extEuclid(a, m) 
    if g != 1:
        return None
    else:
        return x % m

def fme(base, expo, mod):
	"""
	Function that performs Fast Modular Exponentiation
	"""
	x = 1
	y = base
	while (expo > 0):
		if (expo % 2 == 1):
			x = (x * y) % mod
		y = (y * y) % mod
		expo = expo / 2
	return x % mod




s = socket.socket()         
print "Socket created successfully"
print ""
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
port = 12345               
s.bind(('', port))        
print "socket binded to %s" %(port)
print ""
 
s.listen(5)                
print "\nWaiting for client to connect"
print ""


while True:
	c, addr = s.accept()     
	print '\nGot connection from', addr
	print ""
	buff=c.recv(1024)
	buff = buff.strip()
	buff1=buff
	q,g,y1,y2,opcode1 = buff.split(':')
	print "###############################################################"
	print ""
	print ""
	print "opcode1    ", opcode1
	print ""
	print "q     ", q
	print ""
	print "g     ", g
	print ""
	q=int(q)
	g=int(g)
	print "Y1     ",y1
	print ""
	print "Y2      ",y2
	print ""
	print ""
	y1=int(y1)
	y2=int(y2)
	


	print "##################################################################"
	print ""
	print "SIgniture Verification"
	print ""
	print "\nHash Function used is SHA-1"
	print ""


##############SIGNITURE VERIFICATION ############

	buff=c.recv(1024)
	buff = buff.strip()
	#print "buffer" , buff
	message,c1,s1,opcode2 = buff.split(':')
	print ""
	print "opcode 2"
	print opcode2
	print ""
	msg=message
	print "Message received is     ", message
	print ""
	print "c    " ,c1
	print ""
	print "s    ",s1
	print ""
	c2=int(c1,16)
	s1=int(s1)




	# if valid return 1 else return 0
	print "#################################################################################################"
	print ""
	print "Calculation of Aprime"
	print ""
	z1=extendedGcd(int(y1),int(q))
	z=fme(int(g),int(s1),int(q))
	print ""
	print "z=g ** s % q    " , z
	print ""
	  #doubtful
	print "extended gcd between y1 and q     " , z1
	print ""
	z2=fme(int(z1),int(c2),int(q))
	print ""
	print "z ** c % q    " , z2
	print ""
	z3=(z*z2) %q
	#z3=((z % q)*(z2 % q))%q	#seems correct
	Aprime=z3
	print "Aprime=", Aprime
	print ""
	print "####################################################################################################"
	print ""
	print "Calculation of B Prime"
	print ""
	

	z=fme(int(y1),int(s1),int(q))
	print "z=g ** s % q    " , z
	print ""

	z1=extendedGcd(y2,q)



	print "extended gcd between y1 and q     ", z1
	print ""
	# if(z1<0):
	# 	z1+=q
	z2=fme(int(z1),int(c2),int(q))

	print "z2", z2
	print ""
	z3=(z*z2) %q
	#z3=((z % q)*(z2 % q))%q	 #(z*z2)%int(q)
	print "z ** c % q    ", z3
	print ""

	
	Bprime=z3
	print "Bprime",Bprime
	print ""
	print ""
	print "###########################################################################################"
	print ""
	print "Aprime",Aprime
	print "Bprime",Bprime
	print ""
	print "###########################################################################################"
	print ""
	check=str(Aprime)+str(Bprime)+message
	print "check", check
	print ""
	hash_object = hashlib.sha1(check)
	hex_dig = hash_object.hexdigest()
	print "hex_dig calculated", hex_dig
	print ""
	#i = int(hex_dig, 16)
	# "i", i
	print ""
	print "given hex_digest", c1
	print ""
	print "###############################################################################################"
	print ""
	if hex_dig==c1:
		print "VERIFIED"
		status=1
		#c.send("30:1")
	else:
		print "NOT VERIFIED"
		status=0
		#c.send("30:0")
	c.send("30"+":"+str(status))














