import socket 
import pickle
import random
from pickle import * 
import thread
import threading 
import hashlib
import os
import pandas as pd
storage_table=pd.DataFrame(columns=['UserID','Salt','Hashed_Password','Prime'])
#import ipdb
sharedPrime=23 #p q
sharedBase=9 #g alpha
secret_key=3 # p private key X
print_lock = threading.Lock() 
cipher_inp=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',',','.','?','0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','!','\n']



class messageFromClient:
    def __init__(self,primeNumber,primitiveRoot,publicKeyClient):
        self.primeNumber=primeNumber
        self.primitiveRoot=primitiveRoot
        self.publicKeyClient=publicKeyClient


class header:
    def __init__(self,a):
        self.opcode=a
        self.s_addr=1 #source address
        self.d_addr=3 #destination address


class logincreate(header):
    def __init__(self,uid,pwd,large_prime_no,hd):
        #header.__init__(self)   #header for msg
        self.uid=uid    
        self.buf="a"  #plaintext
        self.pwd=pwd #pwd by user
        self.large_prime_no=large_prime_no #prime
        self.status=0 #status 
        self.file="a"
        self.dummy=0
        self.header=hd

def decipher(source,key):
    source1=[0]*len(source)
    source2=[0]*len(source)
    source3=['']*len(source)



    #decipher 

    for i in range(0,len(source)):
        flag=0
        count=0
        for index in cipher_inp:
            if source[i]==index:
                source1[i]=count
                flag=1
            count+=1
        if flag==0:
            return -1

    #shift the stuff
    for i in range(0,len(source)):
        for index in range(0,len(cipher_inp)):
            if source1[i]==index:
                source2[i]=(source1[i]-key)%len(cipher_inp)

    #encipher it

    for i in range(0,len(source)):
        for index in range(0,len(cipher_inp)):
            if source2[i]==index:
                source3[i]=cipher_inp[index]

    source4=''
    for i in source3:
        source4+=i

    return source4
        
def cipher(source,key):
    source1=[0]*len(source)
    source2=[0]*len(source)
    source3=['']*len(source)

    #decipher 

    for i in range(0,len(source)):
        flag=0
        count=0
    
        for index in cipher_inp:
            if source[i]==index:
                source1[i]=count
                flag=1
            count+=1
        if flag==0:
            return -1

    #shift the stuff
    for i in range(0,len(source)):
        for index in range(0,len(cipher_inp)):
            if source1[i]==index:
                source2[i]=(source1[i]+key)%len(cipher_inp)

    #encipher it



    for i in range(0,len(source)):
        for index in range(0,len(cipher_inp)):
            if source2[i]==index:
                source3[i]=cipher_inp[index]
    source4=''
    for i in source3:
        source4+=i

    return source4
        


    

# thread fuction 
def threaded(c): 
    while True: 
  
        # data received from client 
        data = c.recv(8192) 
        try:
            a=pickle.loads(data)
        except EOFError as error:
            pass
            
        if not data: 
            print('Bye') 
              
            # lock released on exit 
            print_lock.release() 
            break

        d=diffie(a.primitiveRoot,5,a.primeNumber)
        c.send(d) 
        shared_sec_key=diffie1(int(a.publicKeyClient),5,a.primeNumber)
        print('The shared secret key that I calculated is ')
        print shared_sec_key
        shared_sec_key%=len(cipher_inp)
        print ('shared secret key modulo 67')
        print shared_sec_key
    # connection closed 
    #####################################END OF PART 1 ######################################################
   #     ipdb.set_trace()


        login_create=c.recv(8192)
        abc=header(1)
        login=logincreate('a','b',5,abc)

        try:
            login=pickle.loads(login_create)
            
            myheader=header(0)
            myheader=login.header

    
##############################END OF PART 2-1 ###################################################

            # myheader mei mera header hoga
            #login mei login rahega
            global storage_table
            decrypted_uid=decipher(login.uid,shared_sec_key)
            print "decrepted User ID"
            print decrypted_uid
            decrypted_pwd=decipher(login.pwd,shared_sec_key)

            print "decrypted password"
            print decrypted_pwd
# THE LOGIN AND ALL IS DONE. WE NEED TO CHECK THE OUTPUT
            the_login_pwd=login.pwd
            print "My header Opcode"
            print myheader.opcode

            print "decrypted prime"
            decryped_prime=decipher(login.large_prime_no,shared_sec_key)
            print decryped_prime
            if (myheader.opcode==10):
                #logincreate
                # salt generate karo

                salt=random.randrange(1,10000,1)
               # password+salt+login.large_prime_no

                concatted_pwd=decrypted_pwd+str(salt)+str(decryped_prime)

                hash_object = hashlib.sha1(concatted_pwd)
                hex_dig = hash_object.hexdigest()
                print "Salt"
                print salt
                print "the concat password befor applying SHA1"

                print "Hashed Password"
                print hex_dig
                print "large prime no(q prime)"
                print login.large_prime_no
###################################################################################################
###################################################################################################
              #      ERROR HANDLING HERE
####################################################################################################
####################################################################################################

                flag=0
                for i in range(0,len(storage_table)):
                    x=storage_table.iloc[i]
                    
                    y=x['UserID']
                    if y==decrypted_uid:
                        flag=1
                hdd=header(20)
                a=logincreate(login.uid,login.pwd,1,hdd)
                if flag==1:
                    #return message that the person is unsuccessful                
                    a.status=0 # 0 for unsuccessful, 1 for successful
                else:
                    a.status=1

                a.uid=login.uid
                a.pwd=login.pwd
                a.large_prime_no=login.large_prime_no
                b=pickle.dumps(a)
                c.send(b)

                if a.status==1:

                        #print "PPPPPPPPPPPPPPPPPP"
                    data_insert_table=pd.DataFrame([[decrypted_uid,salt,hex_dig,decryped_prime]],columns=['UserID','Salt','Hashed_Password','Prime'])
                    
                    
                    storage_table=storage_table.append(data_insert_table)

                    print "THE STORAGE TABLE"
                    print storage_table
                else:
                    print "User ID already exists"




##########################END OF PART2-2 ##############


###########################END OF PART 2-3 ###############


            elif (myheader.opcode==30):

                #request access from the server
                print "Authenticate from the server"
                flag=0
                for i in range(0,len(storage_table)):
                    x=storage_table.iloc[i]
                    
                    y=x['UserID']
                    if y==decrypted_uid:
                        loginpwd=decipher(login.pwd,shared_sec_key)
                        concatted_pwd=loginpwd+str(x['Salt'])+str(x['Prime'])

                        hash_object = hashlib.sha1(concatted_pwd)
                        hex_dig = hash_object.hexdigest()

                        if (hex_dig==x['Hashed_Password']):

                            flag=1


                #send reply here is login success or failed
                hdd1 =header(40)
                rep=logincreate(login.uid,login.pwd,23,hdd1)

                if flag==1:
                    rep.status=1
                else:
                    rep.status=0
                data_string1 = pickle.dumps(rep)
                # message sent to server 
                c.send(data_string1)




                if flag==1:
                    # present in the table
                    print "SUCCESS AUTHENTICATE"
                    file_name_dataset=c.recv(8192)
                    # here u get the file dataset
                    abc=header(1)
                    login=logincreate('a','b',5,abc)

                    file1=pickle.loads(file_name_dataset)
                    my_file_name=file1.file
                    file_size=os.path.getsize(my_file_name)
                    no_of_chunks=file_size/1024
                    if(no_of_chunks*1024<file_size):
                        no_of_chunks+=1
                    
                    file1.dummy=no_of_chunks
                
                    #print file1.dummy
                    print("Request to access")
                    
                    file1.status=1
                    print my_file_name

                    f = open(my_file_name, "rb")
                    print "opened the file"

                    while True:
                        file1.buf = f.read(1024)
                       # print file1.buf
                        if not file1.buf:
                            break
                        else:
                            xyzzz=cipher(file1.buf,shared_sec_key)

                            file1.buf=xyzzz
                            data_string = pickle.dumps(file1)
                            # message sent to server 
                            c.send(data_string)

                    



                else:
                    #return failed with error code
                    login.status=0
                    print "FAILED AUTHENTICATE"
                    data_string = pickle.dumps(login)
                    # message sent to server 
                    c.send(data_string)
                    print_lock.release()
                    break

        
        except (EOFError,IndexError,OSError), error:
            pass


        if not login:
            print_lock.release()
            break



    c.close() 




def diffie(sharedBase,secret_key,sharedPrime):
    A = (sharedBase**secret_key) % sharedPrime
    return str(A)

def diffie1(y,secret_key,sharedPrime):
    symm_key_server=y**secret_key % sharedPrime
    return symm_key_server



def Main(): 
    host = "127.0.0.1"

    port = 12345
    
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
    s.bind((host, port)) 
    print("socket binded to port", port) 
  
    # put the socket into listening mode 
    s.listen(5) 
    print("socket is listening") 
  
    # a forever loop until client wants to exit 
    while True: 
  
        # establish connection with client 
        c, addr = s.accept() 
  
        # lock acquired by client 
        print_lock.acquire() 
        print('Connected to :', addr[0], ':', addr[1]) 
        
        print storage_table
        # Start a new thread and return its identifier 
        thread.start_new_thread(threaded, (c,)) 
    s.close() 
  
  
if __name__ == '__main__': 
    Main() 