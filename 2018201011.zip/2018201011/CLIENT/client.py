
# Import socket module 
import socket 
import random 
import pickle
import os
import sys
sharedPrime=23 #p
sharedBase=9 #g
secret_key=4 # p 

cipher_inp=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',',','.','?','0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','!','\n']



START_BASE_FOR_PRIMES=10000
PRIME_RANGE=10000
RABIN_TEST_FREQUENCY=5



# Implementing Rabin Miller to check if the inputForPrime is prime or not (1 - prime, 0 - not prime)
def checkPrimeUsingRabinMiller(inputForPrime):
    # Step 1: Computing k & m such that n-1 = 2^k * m (for some odd m)
    multiplier = inputForPrime - 1
    mmm=0
    while multiplier % 2 == 0:
        multiplier/=2
        mmm+=1

    # Now repeat the test for RABIN_TEST_FREQUENCY time
    for i in range(0,RABIN_TEST_FREQUENCY):
        if(not checkPrimeUsingRabinMillerUtil(inputForPrime, multiplier)):
            return 0
    
    return 1

def computeModularPow(a_random, multiplier, inputForPrime):
    finalResult = 1
    a_random = a_random % inputForPrime
    xyzabc=1
    while(multiplier > 0):
        xyzabc+=1
        if(multiplier % 2):
            
            finalResult = (finalResult * a_random) % inputForPrime
        

        multiplier >>= 1
        mmm=0
        a_random = (a_random * a_random) % inputForPrime
        mmm+=1
    
    return finalResult



def checkPrimeUsingRabinMillerUtil(inputForPrime, multiplier):
    #choosing a random_val in the range [2, n-2]
    a_random = (random.randrange(0,10000,1) % (inputForPrime - 3)) + 2
    
    #computing Modular Exponentiation & Checking the primality Conditions 
    b_0 = computeModularPow(a_random, multiplier, inputForPrime)
    
    if(b_0 == 1 or b_0 == inputForPrime - 1):
        return 1

    while(multiplier < inputForPrime - 1):

        b_0 = (b_0 * b_0) % inputForPrime
        multiplier *= 2

        if(b_0 == inputForPrime-1):
            return 1
        if(b_0 == 0):
            return 0
    
    return 0





def calcPrimitiveRoot(primeNumber):
    candidates=[0]*(primeNumber)
    primRoot=0
    notRoot = 0

    #Try for all numbers from 2 to p-1
    m_c1=0
    m_c2=0
    for r in range(2,primeNumber):
        m_c1+=1
        for x in range(0,primeNumber-1):
            m_c2+=1
            candidates[x] = computeModularPow(r, x, primeNumber)
        
    #print m_c1
    #print m_c2
        mm1=0
        mm2=0
        # Check for duplicates in the candidate array
        for i in range(0,primeNumber):
            mm1+=1
            for j in range(0,primeNumber):
                mm2+=1
                if(candidates[i] == candidates[j] and not i == j):
                    notRoot = 1
                    break
                
            
            if(notRoot):
                break
        if(mm1>mm2):
            print "error"

        if(notRoot):
            notRoot = 0
            primRoot = -1
        
        else:
            primRoot = r
            break
        
    

    return primRoot

class messageFromClient:
    def __init__(self,primeNumber,primitiveRoot,publicKeyClient):
        self.primeNumber=primeNumber
        self.primitiveRoot=primitiveRoot
        self.publicKeyClient=publicKeyClient


class header:
    def __init__(self,a):
        self.opcode=a
        self.s_addr=1 #source address
        self.d_addr=3 #destination address


class logincreate(header):
    def __init__(self,uid,pwd,large_prime_no,hd):
        #header.__init__(self)   #header for msg
        self.uid=uid    
        self.buf="a" #plaintext
        self.pwd=pwd #pwd by user
        self.large_prime_no=large_prime_no #prime
        self.status=0 #status 
        self.file="a"
        self.dummy=0
        self.header=hd
    


def cipher(source,key):
    source1=[0]*len(source)
    source2=[0]*len(source)
    source3=['']*len(source)



    #decipher 

    for i in range(0,len(source)):
        flag=0
        count=0
        for index in cipher_inp:
            if source[i]==index:
                source1[i]=count
                flag=1
            count+=1
        if flag==0:
            return -1

    #shift the stuff
    for i in range(0,len(source)):
        for index in range(0,len(cipher_inp)):
            if source1[i]==index:
                source2[i]=(source1[i]+key)%len(cipher_inp)

    #encipher it

    for i in range(0,len(source)):
        for index in range(0,len(cipher_inp)):
            if source2[i]==index:
                source3[i]=cipher_inp[index]

    source4=''
    for i in source3:
        source4+=i

    return source4
        

def decipher(source,key):
    source1=[0]*len(source)
    source2=[0]*len(source)
    source3=['']*len(source)



    #decipher 

    for i in range(0,len(source)):
        flag=0
        count=0
        for index in cipher_inp:
            if source[i]==index:
                source1[i]=count
                flag=1
            count+=1
        if flag==0:
            return -1

    #shift the stuff
    for i in range(0,len(source)):
        for index in range(0,len(cipher_inp)):
            if source1[i]==index:
                source2[i]=(source1[i]-key)%len(cipher_inp)

    #encipher it

    for i in range(0,len(source)):
        for index in range(0,len(cipher_inp)):
            if source2[i]==index:
                source3[i]=cipher_inp[index]

    source4=''
    for i in source3:
        source4+=i

    return source4     

  
def Main(): 
    # local host IP '127.0.0.1' 
   # host = '127.0.0.1'  #needs tobe input type
	if(len(sys.argv)<2):
		print "GIVE HOST IP"
		sys.exit()

	host=sys.argv[1]
    # Define the port on which you want to connect 
	port = 12345    #needs to be input type

	primeNumber=START_BASE_FOR_PRIMES+random.randrange(0,10000,1)
    
	while(not checkPrimeUsingRabinMiller(primeNumber)):
		primeNumber = START_BASE_FOR_PRIMES+random.randrange(0,10000,1)
        
	print "primeNumber(q):"
	print primeNumber
    # i got my prime number

    # calculate alpha
	primitiveRoot = calcPrimitiveRoot(primeNumber)
	print "primitiveRoot(alpha)"
	print primitiveRoot

	privatekeyClient=random.randrange(0,primeNumber-1,1)
	print "privatekeyClient"
	print privatekeyClient


	s = socket.socket(socket.AF_INET,socket.SOCK_STREAM) 

	# connect to server on local computer 
	s.connect((host,port)) 

	message1=diffie(primeNumber,primitiveRoot,privatekeyClient)

	m1=messageFromClient(primeNumber, primitiveRoot, message1)

	data_string = pickle.dumps(m1)
	# message sent to server 
	s.send(data_string) 

	# messaga received from server 
	data = s.recv(8192) 

	# print the received message 
	# here it would be a reverse of sent message 
	# print('Received from the server :',str(data.decode('ascii')))
	print "received key from server"
	print int(data)
	print "shared Key(calculated as y^secret key modulo shared prime" 
	shared_sec_key=diffie1(int(data),privatekeyClient,primeNumber)
	print('The shared secret key before modding is ')
	print shared_sec_key
	shared_sec_key=shared_sec_key % len(cipher_inp)
	print 'shared secret key that is modded with len(cipher) is '
	print shared_sec_key


	# close the connection 

	############################# PART 1 ENDED #################################################

	print("1. Login Create")
	print("2. Login")

	x=input("select")

	uid=raw_input("Enter ID")
	pwd=raw_input("Enter password")
	while(len(pwd)>10):
		print "Exceed amount of character in password"
		pwd=raw_input("Enter password")


	if x==1:
		print "NEW LOGIN (CREATE)"

		large_prime_no=START_BASE_FOR_PRIMES+random.randrange(0,10000,1)

		while(not checkPrimeUsingRabinMiller(large_prime_no)):
			large_prime_no = START_BASE_FOR_PRIMES+random.randrange(0,10000,1)

		hdd=header(10)




		a=logincreate(uid,pwd,large_prime_no,hdd)

		# apply generalised ceaser cipher to encrypt id,pwd,large prime number
		#use shared_sec_key


		a.uid=cipher(a.uid,shared_sec_key)
		print "Encrypted uid"
		print a.uid
		a.pwd=cipher(a.pwd,shared_sec_key)
		print "Encrypted password"
		print a.pwd

		xxx=cipher(str(a.large_prime_no),shared_sec_key)
		a.large_prime_no=xxx

		b=pickle.dumps(a)
		s.send(b)
		reply=s.recv(8192)
		op=pickle.loads(reply)
		if op.status==0:
			print "UNSUCCESSFUL"
			print "USER ID ALREADY EXISTS"
		else:
			print "SUCCESS"


	else:


		#login with right pwd n stuff
		hdd=header(30)

		a=logincreate(uid,pwd,23,hdd)

		a.uid=cipher(a.uid,shared_sec_key)
		print "ENcrypted User ID"
		print a.uid
		a.pwd=cipher(a.pwd,shared_sec_key)
		print "Encrypted password"
		print a.pwd
		xxx=cipher(str(a.large_prime_no),shared_sec_key)
		a.large_prime_no=xxx

		b=pickle.dumps(a)


		s.send(b)

		reply=s.recv(8192)
		op=pickle.loads(reply)

		if op.status==0:
			print a.uid
			print "UNSUCCESSFUL"
			print "WRONG COMBINATION"
		else:
			print "SUCCESS"
			p=raw_input("Name the file you want.")
			# make a packet
			hddxyz=header(50)

			an=logincreate(uid,pwd,23,hddxyz)
			an.uid=cipher(an.uid,shared_sec_key)
			an.pwd=cipher(an.pwd,shared_sec_key)
			an.file=p
			bn=pickle.dumps(an)
			s.send(bn)
			p1="client_"+p
			f = open(p1,'wb')



			num_of_chunks=0
			myfile=s.recv(8192)

			file_det=pickle.loads(myfile)
			pp=decipher(file_det.buf,shared_sec_key)
			f.write(pp)
			num_of_chunks+=1
			final_chunks=file_det.dummy

			while(num_of_chunks<final_chunks):
				myfile=s.recv(8192)
				file_det=pickle.loads(myfile)
				pp=decipher(file_det.buf,shared_sec_key)
				f.write(pp)
				num_of_chunks+=1
			f.close()

			


	s.close() 
  
def diffie(sharedPrime,sharedBase,secret_key):
    A = (sharedBase**secret_key) % sharedPrime
    A=str(A)
    return A
    # send the generated key to the server


def diffie1(y,secret_key,sharedPrime):
  #  y=#receive the public key from server

    # compute symmetric key
    symm_key_client=y**secret_key % sharedPrime
    return symm_key_client

    
    # symm_key_client is the shared secret key


if __name__ == '__main__': 
    Main() 
